@echo off
title Big Daddy Games Installer
echo Installing Big Daddy Games dependencies...
call npm install
if not exist .env copy .env.example .env
echo.
echo Installation complete. Edit .env, then run start.bat.
pause
