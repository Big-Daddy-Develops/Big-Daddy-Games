require('dotenv').config();
const Database = require('better-sqlite3');
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const pkg = require('../package.json');

const TOKEN=process.env.DISCORD_TOKEN, CLIENT_ID=process.env.CLIENT_ID, TEST_GUILD_ID=process.env.TEST_GUILD_ID;
const GITHUB_OWNER='Big-Daddy-Develops', GITHUB_REPO='Big-Daddy-Games';
const GITHUB_RELEASES_URL=`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`;
const GITHUB_REPO_URL=`https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}`;
if(!TOKEN||!CLIENT_ID) throw new Error('Set DISCORD_TOKEN and CLIENT_ID');
const db=new Database('big-daddy-games.db'); db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS stats (guild_id TEXT NOT NULL,user_id TEXT NOT NULL,wins INTEGER NOT NULL DEFAULT 0,losses INTEGER NOT NULL DEFAULT 0,draws INTEGER NOT NULL DEFAULT 0,games INTEGER NOT NULL DEFAULT 0,streak INTEGER NOT NULL DEFAULT 0,best_streak INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(guild_id,user_id));`);
const ensure=db.prepare('INSERT OR IGNORE INTO stats(guild_id,user_id) VALUES(?,?)');
const win=db.prepare('UPDATE stats SET wins=wins+1,games=games+1,streak=streak+1,best_streak=MAX(best_streak,streak+1) WHERE guild_id=? AND user_id=?');
const lose=db.prepare('UPDATE stats SET losses=losses+1,games=games+1,streak=0 WHERE guild_id=? AND user_id=?');
const draw=db.prepare('UPDATE stats SET draws=draws+1,games=games+1 WHERE guild_id=? AND user_id=?');
const getStats=db.prepare('SELECT * FROM stats WHERE guild_id=? AND user_id=?');
const topStats=db.prepare('SELECT * FROM stats WHERE guild_id=? ORDER BY wins DESC,best_streak DESC,games ASC LIMIT 10');
const games=new Map();
const commands=[
 new SlashCommandBuilder().setName('rps').setDescription('Play Rock Paper Scissors').addUserOption(o=>o.setName('player').setDescription('Opponent (leave blank for options)')),
 new SlashCommandBuilder().setName('dice').setDescription('Play a Dice Battle').addUserOption(o=>o.setName('player').setDescription('Opponent (leave blank for options)')),
 new SlashCommandBuilder().setName('rps-open').setDescription('Post an open Rock Paper Scissors challenge'),
 new SlashCommandBuilder().setName('dice-open').setDescription('Post an open Dice Battle challenge'),
 new SlashCommandBuilder().setName('rps-bot').setDescription('Play Rock Paper Scissors against the bot'),
 new SlashCommandBuilder().setName('dice-bot').setDescription('Play Dice Battle against the bot'),
 new SlashCommandBuilder().setName('stats').setDescription('View competitive game stats').addUserOption(o=>o.setName('player').setDescription('Player (defaults to you)')),
 new SlashCommandBuilder().setName('leaderboard').setDescription('Show this server’s competitive leaderboard'),
 new SlashCommandBuilder().setName('games').setDescription('Show available Big Daddy Games'),
 new SlashCommandBuilder().setName('version').setDescription('Show bot version and update configuration'),
 new SlashCommandBuilder().setName('check-update').setDescription('Check GitHub for the latest Big Daddy Games release')
].map(c=>c.toJSON());
const client=new Client({intents:[GatewayIntentBits.Guilds]}); const rest=new REST({version:'10'}).setToken(TOKEN);
function id(){return Math.random().toString(36).slice(2,10)}
function base(t,d){return new EmbedBuilder().setTitle(`🎮 Big Daddy Games — ${t}`).setDescription(d).setFooter({text:`Big Daddy Games v${pkg.version} • centrally hosted`}).setTimestamp()}
function mention(u){return `<@${u}>`}
function challengeButtons(g){return new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`accept:${g.id}`).setLabel(g.open?'Accept Open Challenge':'Accept Challenge').setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId(`cancel:${g.id}`).setLabel('Cancel').setStyle(ButtonStyle.Secondary))}
function modeButtons(type){return new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`newopen:${type}`).setLabel('Open Challenge').setEmoji('⚔️').setStyle(ButtonStyle.Primary),new ButtonBuilder().setCustomId(`newbot:${type}`).setLabel('Play vs Bot').setEmoji('🤖').setStyle(ButtonStyle.Success))}
function rpsButtons(g){return new ActionRowBuilder().addComponents(['rock','paper','scissors'].map((x,n)=>new ButtonBuilder().setCustomId(`pick:${g.id}:${x}`).setLabel(x[0].toUpperCase()+x.slice(1)).setEmoji(['🪨','📄','✂️'][n]).setStyle(ButtonStyle.Primary)))}
function diceButton(g){return new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`roll:${g.id}`).setLabel('Roll Dice').setEmoji('🎲').setStyle(ButtonStyle.Primary))}
function playButton(g){return new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`reveal:${g.id}`).setLabel('PLAY — Reveal Result').setEmoji('🎮').setStyle(ButtonStyle.Success))}
function record(g,winner){if(g.bot) return; [g.p1,g.p2].forEach(u=>ensure.run(g.guild,u));if(!winner){draw.run(g.guild,g.p1);draw.run(g.guild,g.p2)}else{const loser=winner===g.p1?g.p2:g.p1;win.run(g.guild,winner);lose.run(g.guild,loser)}}
function makeGame(type,guild,p1,p2=null,extra={}){const g={id:id(),type,guild,p1,p2,accepted:false,open:false,bot:false,choices:{},rolls:{},revealed:false,...extra};games.set(g.id,g);return g}
function gameName(g){return g.type==='rps'?'Rock Paper Scissors':'Dice Battle'}
async function startAccepted(i,g){g.accepted=true;if(g.bot){g.p2=client.user.id;if(g.type==='rps')g.choices[g.p2]=['rock','paper','scissors'][Math.floor(Math.random()*3)];else g.rolls[g.p2]=Math.floor(Math.random()*6)+1}
 const text=g.bot?`${mention(g.p1)} vs 🤖 **Big Daddy Bot**\n\nYour opponent has secretly locked in. Your turn!`:`${mention(g.p1)} vs ${mention(g.p2)}\n\n🔐 ${g.type==='rps'?'Both players choose secretly.':'Both players roll secretly.'}`;
 return i.update({embeds:[base(gameName(g),text)],components:[g.type==='rps'?rpsButtons(g):diceButton(g)]})}
function normalizeVersion(v){return String(v||'').trim().replace(/^v/i,'')}
function compareVersions(a,b){const pa=normalizeVersion(a).split('.').map(n=>parseInt(n,10)||0),pb=normalizeVersion(b).split('.').map(n=>parseInt(n,10)||0);for(let x=0;x<Math.max(pa.length,pb.length);x++){const d=(pa[x]||0)-(pb[x]||0);if(d)return d>0?1:-1}return 0}
async function checkUpdate(){const r=await fetch(GITHUB_RELEASES_URL,{headers:{'Accept':'application/vnd.github+json','User-Agent':'Big-Daddy-Games'}});if(r.status===404)return {noRelease:true,repo:GITHUB_REPO_URL};if(!r.ok)throw new Error(`GitHub HTTP ${r.status}`);const m=await r.json();const latest=normalizeVersion(m.tag_name||m.name);return {latest,url:m.html_url||GITHUB_REPO_URL,notes:m.body||'',updateAvailable:compareVersions(latest,pkg.version)>0}}
client.once('ready',async()=>{console.log(`Big Daddy Games v${pkg.version} logged in as ${client.user.tag}`);if(TEST_GUILD_ID)await rest.put(Routes.applicationGuildCommands(CLIENT_ID,TEST_GUILD_ID),{body:commands});else await rest.put(Routes.applicationCommands(CLIENT_ID),{body:commands});console.log('Commands registered.');});
client.on('interactionCreate',async i=>{try{
 if(i.isChatInputCommand()){
  if(!i.guildId)return i.reply({content:'Games must be played in a server.',ephemeral:true});
  if(i.commandName==='games')return i.reply({embeds:[base('Game Room','🪨 **Rock Paper Scissors** — direct, open challenge, or bot\n🎲 **Dice Battle** — direct, open challenge, or bot\n📊 `/stats` • 🏆 `/leaderboard`\n\nBot matches are for fun/testing and do **not** affect competitive stats.')],components:[modeButtons('rps'),modeButtons('dice')]});
  if(i.commandName==='version')return i.reply({embeds:[base('Version',`Running **v${pkg.version}**\nUpdate source: **${GITHUB_OWNER}/${GITHUB_REPO}**\n\nThe bot checks GitHub Releases. Big Daddy Hosting should deploy/restart updates; the bot does not overwrite its own files.`)],ephemeral:true});
  if(i.commandName==='check-update'){await i.deferReply({ephemeral:true});try{const u=await checkUpdate();if(u.noRelease)return i.editReply(`ℹ️ No GitHub Release has been published yet. Running **v${pkg.version}**.`);if(!u.updateAvailable)return i.editReply(`✅ Big Daddy Games v${pkg.version} is current. Latest GitHub release: **v${u.latest}**.`);const notes=u.notes?`\n\n${u.notes.slice(0,1200)}`:'';return i.editReply(`⬆️ Big Daddy Games **v${u.latest}** is available (running v${pkg.version}).${notes}\n\n${u.url}`)}catch(e){return i.editReply(`Update check failed: ${e.message}`)}}
  if(i.commandName==='stats'){const u=i.options.getUser('player')||i.user;ensure.run(i.guildId,u.id);const s=getStats.get(i.guildId,u.id);return i.reply({embeds:[base('Player Stats',`**${u.displayName}**\n🏆 Wins: **${s.wins}**\n💥 Losses: **${s.losses}**\n🤝 Draws: **${s.draws}**\n🎮 Games: **${s.games}**\n🔥 Current streak: **${s.streak}**\n⭐ Best streak: **${s.best_streak}**\n\n*Competitive human-vs-human matches only.*`)]})}
  if(i.commandName==='leaderboard'){const rows=topStats.all(i.guildId),text=rows.length?rows.map((s,n)=>`${n+1}. ${mention(s.user_id)} — **${s.wins} wins** • 🔥 ${s.best_streak}`).join('\n'):'No competitive games played yet.';return i.reply({embeds:[base('Leaderboard',text)]})}
  let type=null,mode=null,opponent=null;
  if(['rps','dice'].includes(i.commandName)){type=i.commandName;opponent=i.options.getUser('player');if(!opponent)return i.reply({embeds:[base(gameName({type}),'Choose how you want to play:')],components:[modeButtons(type)],ephemeral:true});mode='direct'}
  if(i.commandName==='rps-open'){type='rps';mode='open'} if(i.commandName==='dice-open'){type='dice';mode='open'} if(i.commandName==='rps-bot'){type='rps';mode='bot'} if(i.commandName==='dice-bot'){type='dice';mode='bot'}
  if(type){if(mode==='direct'){if(opponent.bot)return i.reply({content:'Use the Play vs Bot option instead.',ephemeral:true});if(opponent.id===i.user.id)return i.reply({content:'You cannot challenge yourself.',ephemeral:true});const g=makeGame(type,i.guildId,i.user.id,opponent.id);return i.reply({embeds:[base(gameName(g),`${mention(g.p1)} has challenged ${mention(g.p2)}!\n\n${mention(g.p2)}, accept to begin.`)],components:[challengeButtons(g)]})}
   if(mode==='open'){const g=makeGame(type,i.guildId,i.user.id,null,{open:true});return i.reply({embeds:[base(`${gameName(g)} — Open Challenge`,`${mention(g.p1)} is looking for an opponent!\n\n⚔️ First player to press **Accept Open Challenge** gets the match.`)],components:[challengeButtons(g)]})}
   if(mode==='bot'){const g=makeGame(type,i.guildId,i.user.id,client.user.id,{bot:true,accepted:true});if(type==='rps')g.choices[g.p2]=['rock','paper','scissors'][Math.floor(Math.random()*3)];else g.rolls[g.p2]=Math.floor(Math.random()*6)+1;return i.reply({embeds:[base(`${gameName(g)} — vs Bot`,`${mention(g.p1)} vs 🤖 **Big Daddy Bot**\n\nThe bot has secretly locked in. Your turn!`)],components:[type==='rps'?rpsButtons(g):diceButton(g)]})}
  }
 }
 if(!i.isButton())return;const [action,gid,value]=i.customId.split(':');
 if(action==='newopen'||action==='newbot'){const type=gid;if(action==='newopen'){const g=makeGame(type,i.guildId,i.user.id,null,{open:true});return i.reply({embeds:[base(`${gameName(g)} — Open Challenge`,`${mention(g.p1)} is looking for an opponent!\n\n⚔️ First player to accept gets the match.`)],components:[challengeButtons(g)]})}const g=makeGame(type,i.guildId,i.user.id,client.user.id,{bot:true,accepted:true});if(type==='rps')g.choices[g.p2]=['rock','paper','scissors'][Math.floor(Math.random()*3)];else g.rolls[g.p2]=Math.floor(Math.random()*6)+1;return i.reply({embeds:[base(`${gameName(g)} — vs Bot`,`${mention(g.p1)} vs 🤖 **Big Daddy Bot**\n\nThe bot has secretly locked in. Your turn!`)],components:[type==='rps'?rpsButtons(g):diceButton(g)]})}
 const g=games.get(gid);if(!g)return i.reply({content:'This game has expired or finished.',ephemeral:true});
 if(action==='cancel'){if(i.user.id!==g.p1)return i.reply({content:'Only the challenger can cancel.',ephemeral:true});games.delete(g.id);return i.update({embeds:[base('Game Cancelled','The challenge was cancelled.')],components:[]})}
 if(action==='accept'){if(g.open){if(i.user.id===g.p1)return i.reply({content:'You cannot accept your own open challenge.',ephemeral:true});if(g.p2)return i.reply({content:'Someone already accepted this challenge.',ephemeral:true});g.p2=i.user.id;return startAccepted(i,g)}if(i.user.id!==g.p2)return i.reply({content:'Only the challenged player can accept.',ephemeral:true});return startAccepted(i,g)}
 if(![g.p1,g.p2].includes(i.user.id))return i.reply({content:'You are not a player in this game.',ephemeral:true});if(!g.accepted)return i.reply({content:'The challenge has not been accepted yet.',ephemeral:true});
 if(action==='pick'){if(g.type!=='rps')return;if(g.choices[i.user.id])return i.reply({content:'Your choice is already locked.',ephemeral:true});g.choices[i.user.id]=value;await i.reply({content:`🔒 Your **${value}** choice is locked.`,ephemeral:true});if(g.choices[g.p1]&&g.choices[g.p2])await i.message.edit({embeds:[base('Rock Paper Scissors',`${mention(g.p1)}: 🔒 Locked\n${g.bot?'🤖 Big Daddy Bot':mention(g.p2)}: 🔒 Locked\n\nBoth choices are ready. Hit **PLAY**!`)],components:[playButton(g)]});else await i.message.edit({embeds:[base('Rock Paper Scissors',`${mention(g.p1)}: ${g.choices[g.p1]?'🔒 Locked':'⏳ Choosing…'}\n${g.bot?'🤖 Big Daddy Bot':mention(g.p2)}: ${g.choices[g.p2]?'🔒 Locked':'⏳ Choosing…'}`)],components:[rpsButtons(g)]})}
 if(action==='roll'){if(g.type!=='dice')return;if(g.rolls[i.user.id])return i.reply({content:'Your roll is already locked.',ephemeral:true});g.rolls[i.user.id]=Math.floor(Math.random()*6)+1;await i.reply({content:'🔒 Your dice result is locked until reveal.',ephemeral:true});if(g.rolls[g.p1]&&g.rolls[g.p2])await i.message.edit({embeds:[base('Dice Battle',`${mention(g.p1)}: 🔒 Rolled\n${g.bot?'🤖 Big Daddy Bot':mention(g.p2)}: 🔒 Rolled\n\nBoth rolls are ready. Hit **PLAY**!`)],components:[playButton(g)]})}
 if(action==='reveal'){if(g.revealed)return i.reply({content:'Already revealed.',ephemeral:true});g.revealed=true;let winner=null,desc='';const p2name=g.bot?'🤖 **Big Daddy Bot**':mention(g.p2);if(g.type==='rps'){const a=g.choices[g.p1],b=g.choices[g.p2],emoji={rock:'🪨',paper:'📄',scissors:'✂️'};if(a!==b){const beats={rock:'scissors',paper:'rock',scissors:'paper'};winner=beats[a]===b?g.p1:g.p2}desc=`${mention(g.p1)} — ${emoji[a]} **${a.toUpperCase()}**\n${p2name} — ${emoji[b]} **${b.toUpperCase()}**\n\n${winner?(winner===g.p2&&g.bot?'🤖 **Big Daddy Bot wins!**':`🏆 **${mention(winner)} wins!**`):'🤝 **DRAW!**'}`}else{const a=g.rolls[g.p1],b=g.rolls[g.p2];if(a!==b)winner=a>b?g.p1:g.p2;desc=`${mention(g.p1)} — 🎲 **${a}**\n${p2name} — 🎲 **${b}**\n\n${winner?(winner===g.p2&&g.bot?'🤖 **Big Daddy Bot wins!**':`🏆 **${mention(winner)} wins!**`):'🤝 **DRAW!**'}`}record(g,winner);games.delete(g.id);return i.update({embeds:[base(`${gameName(g)} — Result`,desc+(g.bot?'\n\n*Bot matches do not affect competitive stats.*':''))],components:[]})}
 }catch(e){console.error(e);if(i.replied||i.deferred)await i.followUp({content:'Something went wrong.',ephemeral:true}).catch(()=>{});else await i.reply({content:'Something went wrong.',ephemeral:true}).catch(()=>{})}});
client.login(TOKEN);
