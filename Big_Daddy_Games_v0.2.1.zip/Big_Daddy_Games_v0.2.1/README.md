# Big Daddy Games v0.2.1
Central-hosted Discord mini-games bot.

## Games
- Rock Paper Scissors: direct challenge, open challenge, or vs bot
- Dice Battle: direct challenge, open challenge, or vs bot
- Hidden selections/results until PLAY reveal
- Competitive stats and per-server leaderboard
- Bot/test games do not affect competitive stats

## Commands
`/games`, `/rps`, `/dice`, `/rps-open`, `/dice-open`, `/rps-bot`, `/dice-bot`, `/stats`, `/leaderboard`, `/version`, `/check-update`

## Hosting
Requires Node.js 20+ (Node 22 recommended). Run `npm install`, set `DISCORD_TOKEN` and `CLIENT_ID`, then `npm start`.

For central hosting, updates should be deployed by the hosting platform rather than allowing the bot to overwrite its own executable files. `/check-update` can read a JSON manifest from `UPDATE_MANIFEST_URL` and report whether a newer release exists.

Example manifest:
```json
{"version":"0.2.0","download_url":"https://example.invalid/release.zip","notes":"Release notes"}
```
