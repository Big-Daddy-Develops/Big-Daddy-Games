@echo off
title Big Daddy Games
if not exist node_modules (
 echo Installing dependencies...
 call npm install
)
npm start
pause
